import { ArrowRight, Calculator, TreeDeciduous, Sparkles, TrendingUp, Leaf, UserRound, Globe2, Car, AirVent, Laptop, Info } from 'lucide-react';
import { PublicNavbar, Footer } from '../../components/layout/PublicLayout';
import { Button } from '../../components/common/Button';
import { useLang } from '../../context/LangContext';

const FEATURES = [
  [Calculator, 'landing.f1', 'landing.f1d', 'bg-peach text-terracotta'],
  [TreeDeciduous, 'landing.f2', 'landing.f2d', 'bg-olive text-white'],
  [Sparkles, 'landing.f3', 'landing.f3d', 'bg-peach text-terracotta'],
  [TrendingUp, 'landing.f4', 'landing.f4d', 'bg-olive text-white'],
];

function Tag({ children }) {
  return <span className="inline-flex rounded-full bg-peach px-3 py-1 text-xs font-bold text-terracotta">{children}</span>;
}

function Hero() {
  const { t } = useLang();
  return (
    <section id="beranda" className="relative overflow-hidden">
      <div className="absolute -left-24 top-10 h-80 w-80 rounded-full bg-peach/60 blur-3xl" aria-hidden />
      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-5 pb-16 pt-10 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:pb-24 lg:pt-16">
        <div className="stagger">
          <p className="label-sm mb-4 flex items-center gap-2"><Leaf className="h-4 w-4 text-sage" aria-hidden />Emisify</p>
          <h1 className="text-[2.6rem] font-extrabold leading-[1.05] sm:text-6xl lg:text-[4.1rem]" data-testid="landing-hero-title">
            {t('landing.title1')}<br /><span className="text-burnt">{t('landing.title2')}</span><br />{t('landing.title3')}
          </h1>
          <p className="mt-6 max-w-md text-lg text-muted">{t('landing.subtitle')}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" to="/register" iconRight={ArrowRight} data-testid="landing-hero-cta">{t('landing.cta')}</Button>
            <Button size="lg" variant="outline" onClick={() => document.getElementById('cara-kerja')?.scrollIntoView({ behavior: 'smooth' })} data-testid="landing-how-button">{t('landing.ctaSecondary')}</Button>
          </div>
        </div>
        <div className="relative animate-pop">
          <div className="overflow-hidden rounded-[3rem_3rem_3rem_1rem] shadow-lift">
            <img src="/assets/hero-city.jpg" alt="Kota hijau di tepi air dengan pohon sakura" className="aspect-[4/3.6] w-full object-cover" />
          </div>
          <div className="absolute -bottom-6 left-4 flex max-w-[16rem] items-center gap-3 rounded-3xl bg-white/95 p-4 shadow-lift sm:-left-8">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-peach text-terracotta"><Car className="h-5 w-5" aria-hidden /></span>
            <p className="text-xs text-muted"><span className="block text-xl font-extrabold text-ink">±1,0 kg CO₂e</span>{t('landing.heroStat')}</p>
          </div>
          <img src="/assets/tree.png" alt="" className="absolute -right-2 -top-6 h-20 w-20 animate-sway sm:h-24 sm:w-24" />
        </div>
      </div>
    </section>
  );
}

function Features() {
  const { t } = useLang();
  return (
    <section id="fitur" className="mx-auto max-w-6xl px-5 py-10 sm:px-8">
      <div className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4">
        {FEATURES.map(([Icon, title, desc, tone], i) => (
          <div key={title} className="group flex flex-col items-start" data-testid={`landing-feature-${i + 1}`}>
            <span className={`mb-4 grid h-14 w-14 place-items-center rounded-[1.25rem_1.25rem_1.25rem_.4rem] transition-transform duration-300 group-hover:-rotate-6 ${tone}`}><Icon className="h-6 w-6" aria-hidden /></span>
            <h3 className="text-lg font-bold">{t(title)}</h3>
            <p className="text-sm text-muted">{t(desc)}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Split({ id, tag, title, body, img, alt, reverse, children }) {
  return (
    <section id={id} className="mx-auto max-w-6xl px-5 py-6 sm:px-8">
      <div className={`grid items-center gap-8 rounded-[2.5rem] bg-cream p-6 sm:p-10 lg:grid-cols-2 lg:gap-14 ${reverse ? 'lg:[&>*:first-child]:order-2' : ''}`}>
        <div>
          <Tag>{tag}</Tag>
          <h2 className="mt-4 text-3xl font-extrabold sm:text-4xl">{title} <span className="text-terracotta">Emisify</span></h2>
          <p className="mt-4 text-base leading-relaxed text-ink/80 sm:text-lg">{body}</p>
          {children}
        </div>
        <img src={img} alt={alt} loading="lazy" className="aspect-[16/8] w-full rounded-[2rem_2rem_2rem_.75rem] object-cover shadow-soft" />
      </div>
    </section>
  );
}

function Problem() {
  const { t } = useLang();
  const items = [[Car, 'landing.p1'], [AirVent, 'landing.p2'], [Laptop, 'landing.p3']];
  return (
    <section className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
      <Tag>{t('landing.problemTag')}</Tag>
      <h2 className="mt-4 max-w-xl text-3xl font-extrabold sm:text-4xl">{t('landing.problemTitle')}</h2>
      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {items.map(([Icon, key], i) => (
          <div key={key} className={`surface flex items-start gap-4 p-6 transition-transform duration-300 hover:-translate-y-1 ${['rounded-blob', 'rounded-leaf', 'rounded-[2rem]'][i]}`}>
            <Icon className="mt-1 h-5 w-5 shrink-0 text-terracotta" aria-hidden />
            <p className="text-[15px] font-medium">{t(key)}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function HowItWorks() {
  const { t } = useLang();
  return (
    <section id="cara-kerja" className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
      <Tag>{t('landing.howTag')}</Tag>
      <h2 className="mt-4 text-3xl font-extrabold sm:text-4xl">{t('landing.howTitle')}</h2>
      <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((n) => (
          <li key={n} className="relative overflow-hidden rounded-[2rem] bg-white p-6 shadow-soft">
            <span className="absolute -right-3 -top-6 text-[6rem] font-extrabold leading-none text-peach/70" aria-hidden>{n}</span>
            <h3 className="relative mt-8 text-lg font-bold">{t(`landing.s${n}`)}</h3>
            <p className="relative mt-1 text-sm text-muted">{t(`landing.s${n}d`)}</p>
          </li>
        ))}
      </ol>
      <p id="asumsi" className="mt-6 flex items-start gap-2 text-sm text-muted"><Info className="mt-0.5 h-4 w-4 shrink-0 text-warning" aria-hidden />{t('landing.note')}</p>
    </section>
  );
}

function Benefits() {
  const { t } = useLang();
  const items = [[Leaf, 'landing.b1', 'bg-peach text-terracotta'], [UserRound, 'landing.b2', 'bg-olive text-ink'], [Globe2, 'landing.b3', 'bg-peach text-terracotta']];
  return (
    <section className="mx-auto max-w-6xl px-5 py-6 sm:px-8">
      <div className="grid items-center gap-8 rounded-[2.5rem] bg-cream p-6 sm:p-10 lg:grid-cols-[1.1fr_1.4fr]">
        <div>
          <Tag>{t('landing.benefitTag')}</Tag>
          <h2 className="mt-4 text-3xl font-extrabold sm:text-4xl">{t('landing.benefitTitle')} <span className="text-terracotta">Emisify</span></h2>
          <p className="mt-4 text-ink/80 sm:text-lg">{t('landing.benefitBody')}</p>
        </div>
        <div className="grid grid-cols-3 divide-x divide-brown/15">
          {items.map(([Icon, key, tone]) => (
            <div key={key} className="flex flex-col items-center px-2 text-center">
              <span className={`mb-3 grid h-14 w-14 place-items-center rounded-full ${tone}`}><Icon className="h-6 w-6" aria-hidden /></span>
              <p className="text-sm font-bold">{t(key)}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Banner() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-6xl px-5 py-10 sm:px-8">
      <div className="relative overflow-hidden rounded-[2.5rem_2.5rem_2.5rem_1rem]">
        <img src="/assets/banner-bridge.jpg" alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/85 via-ink/60 to-ink/10" aria-hidden />
        <div className="relative flex flex-col items-start gap-5 p-8 sm:p-12">
          <h2 className="max-w-md text-3xl font-extrabold text-white sm:text-4xl">{t('landing.banner')}</h2>
          <Button size="lg" to="/register" iconRight={ArrowRight} data-testid="landing-banner-cta">{t('landing.bannerCta')}</Button>
        </div>
      </div>
    </section>
  );
}

export default function LandingPage() {
  const { t } = useLang();
  return (
    <div className="min-h-dvh bg-soft">
      <PublicNavbar />
      <main>
        <Hero />
        <Features />
        <Split id="tentang" tag={t('landing.aboutTag')} title={t('landing.aboutTitle')} body={t('landing.aboutBody')} img="/assets/about-park.jpg" alt="Taman kota dengan gedung tinggi" />
        <Problem />
        <Split tag={t('landing.goalTag')} title={t('landing.goalTitle')} body={t('landing.goalBody')} img="/assets/goal-transit.jpg" alt="Kereta melintas di kota" reverse />
        <HowItWorks />
        <Benefits />
        <Banner />
      </main>
      <Footer />
    </div>
  );
}
